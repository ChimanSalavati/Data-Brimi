#Brimi data collection

### Install and Requirements
#### Prerequisites 
Install via this command for twitter related usage:
```
pip install pandas
pip install numpy
pip install tweepy
```
### Run Stream
This will collect tweets based on keywords from Query_File.txt. Stores in 50 csv files from 1 to 50 for different bias categories and diseases (160000 unique tweets will be in each csv file).

You only need to put your bearer token in the first section of Data.ipynb between "bearer token" and then run it.

### Run Alerts
Running this script may cause unpredicted errors from twitter

